﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Conversor
    {
        static void Main(string[] args)
        {
            int num,opcion;
            string bin;
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine("1. De entero a binario");
            Console.WriteLine("2. De binario a entero");
            Console.Write("Seleccione su opcion: ");
            opcion = int.Parse(Console.ReadLine());
            if (opcion == 1)
            {
                Console.Write("Ingrese un numero entero para convertir a binario: ");
                num = int.Parse(Console.ReadLine());
                bin = EnteroBinario;
                Console.Write("Al decimal {0} le corresponde el binario {1}", num, bin);
            }
            else
            {
/*                Console.Write("Ingrese un numero binario para convertir a entero: ");
                num = int.Parse(Console.ReadLine());
                bin = EnteroBinario;
                Console.Write("Al binario {0} le corresponde el entero {1}", bin, num);
 */           }

        }
        
        
        static string EnteroBinario(int num)
        {
            int resto,result=num;
            string bin="";
            do
            {
                resto = result % 2;
                result = result / 2;
                bin = bin + Convert.ToString(resto);
            } while (result > 1);
            return bin;
        }


        double BinarioDecimal(string num)
        {
            double deci=0;

            return deci;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Ejercicio03
    {
        static void Main(string[] args)
        {
            int num,i,j,flag;
            Console.Write("Ingrese un numero ");
            num = int.Parse(Console.ReadLine());
            for(i=1;i<num;i++)
            {
                flag=0;
                if (i % 2 == 0)
                {
                    flag = 1;
                }
                else
                {
                    for (j = 3; j < num; j++)
                    {
                        if (i % j == 0)
                        {
                            if (i != j)
                            {
                                flag = 1;
                                break;
                            }
                        }
                    }
                }
                if(flag!=1)
                {
                    Console.WriteLine("Primo: "+i);
                }

            }
            Console.ReadKey();
        }
    }
}

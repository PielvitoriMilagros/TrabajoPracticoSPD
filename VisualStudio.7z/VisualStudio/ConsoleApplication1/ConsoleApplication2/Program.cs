﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int alt,i=1,j,flag,x,z,altaux=0;
            Console.Write("Ingrese la altura de su piramide ");
            alt = int.Parse(Console.ReadLine());
//            for (x = 1; x <= alt; x++)
  //          {
            do //for (i = 1; i <= alt; i++)
            {
                flag = 0;
                if (i % 2 == 0)
                {
                    flag = 1;
                }
                if (flag != 1)
                {
                    for (z = 0; z < i; z++)
                    {
                        Console.Write("*");
                    }
                    altaux++;
                }
                Console.WriteLine();
                i++;
            } while (altaux != alt);
 //           }
            Console.ReadKey();



        }
    }
}
